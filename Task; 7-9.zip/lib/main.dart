import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // MaterialApp is the root widget of your Flutter app.
    // It holds the title and home property,
    // home property contains the main page of the app.
    return MaterialApp(
      // This property is used to hide the debug banner when in debug mode
      debugShowCheckedModeBanner: false,
      title: "My App",
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Scaffold is a basic layout structure in Flutter
    // It provides a default app bar, body and floating action button
    return Scaffold(
      appBar: AppBar(
        // The text displayed in the app bar
        title: Text('Home'),
        // The background color of the app bar
        backgroundColor: Colors.black,
        // The leading property is used to add a widget before the title
        leading: IconButton(
          icon: Icon(Icons.menu),
          onPressed: () {
            print("Menu button clicked");
          },
        ),
        // The actions property is used to add widgets at the end of the app bar
        actions: <Widget>[
          IconButton(
              icon: Icon(Icons.notifications_none),
              onPressed: () {
                print("Notification button clicked");
              },
              color: Colors.white54),
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              print("Search button clicked");
            },
            color: Colors.white54,
          )
        ],
        // The elevation property is used to give a shadow effect to the app bar
        elevation: 6,
        // The titleSpacing property is used to adjust the space between the title and leading/actions widgets
        titleSpacing: 12,
      ),
      floatingActionButton: FloatingActionButton(
        // The child property is used to add a icon to the floating action button
        child: Icon(Icons.add),
        // The onPressed property is called when the button is pressed
        onPressed: () {
          print("Add button clicked");
        },
        // The shape property is used to give a custom shape to the button
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16))),
        // The elevation property is used to give a shadow effect to the button
        elevation: 5,
        // The highlightElevation property is used to give a shadow effect when the button is pressed
        highlightElevation: 10,
      ),
    );
  }
}
